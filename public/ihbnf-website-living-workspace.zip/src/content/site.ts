import type { MediaAsset } from "./types";

// Brand-wide settings. Edit this file to update copy, links and media used across the site.
export const site = {
  name: "IHBNF",
  motto: "Idle Hands Bear No Fruit.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://ihbnf.com",
  title: "IHBNF — Idle Hands Bear No Fruit",
  description:
    "IHBNF (Idle Hands Bear No Fruit) is the creative home of author and builder Javier Huertas: The Unwritten Journey — Book One: Why Henry?, the Unfiltr by Javier AI companion app, Sports Wager Helper, and the memoir The Dream of the Payoff.",
  keywords: [
    "IHBNF",
    "Idle Hands Bear No Fruit",
    "Javier Huertas",
    "The Unwritten Journey",
    "Why Henry",
    "Why Henry book",
    "Unfiltr by Javier",
    "Unfiltr app",
    "YA fantasy books",
    "young adult fantasy",
    "independent author",
    "AI companion app",
    "Sports Wager Helper",
    "sports analytics",
  ],
  founder: {
    name: "Javier Huertas",
    roles: ["Author", "Creator", "Builder"],
    photo: {
      src: "/media/author/javier-huertas-author.jpg",
      alt: "Author Javier Huertas",
      width: 1200,
      height: 1500,
    } as MediaAsset,
  },
  logo: {
    src: "/media/brand/ihbnf-icon.svg",
    alt: "IHBNF — Idle Hands Bear No Fruit",
    width: 128,
    height: 128,
  } as MediaAsset,
  // Split on purpose so the address never appears as plain text in the page source.
  email: { user: "ihbnfllc", domain: "gmail.com" },
};

export const links = {
  amazonWhyHenry: "https://a.co/d/0cFlHSYB",
  unfiltrSite: "https://unfiltrbyjavier.com",
  unfiltrAppStore:
    "https://apps.apple.com/us/app/unfiltr-by-javier-ai-friend/id6760604917",
  unfiltrGooglePlay:
    "https://play.google.com/store/apps/details?id=com.huertas.unfiltr",
  sportsWagerHelper: "https://sportswagerhelper.com",
};

export type NavItem = { id: string; label: string };

export const nav: NavItem[] = [
  { id: "home", label: "Home" },
  { id: "work", label: "Projects" },
  { id: "books", label: "Books" },
  { id: "apps", label: "Apps" },
  { id: "sports", label: "Sports" },
  { id: "about", label: "About" },
  { id: "connect", label: "Connect" },
];

export type SocialKey =
  | "youtube"
  | "threads"
  | "bluesky"
  | "pinterest"
  | "instagram"
  | "facebook"
  | "tiktok";

export type Social = { key: SocialKey; label: string; handle: string; href: string };

export const socials: Social[] = [
  { key: "youtube", label: "YouTube", handle: "@IHBNF", href: "https://www.youtube.com/@IHBNF" },
  { key: "instagram", label: "Instagram", handle: "@unfiltrbyjavier", href: "https://www.instagram.com/unfiltrbyjavier/" },
  { key: "tiktok", label: "TikTok", handle: "@unfiltrbyjavier", href: "https://www.tiktok.com/@unfiltrbyjavier" },
  { key: "threads", label: "Threads", handle: "@unfiltrbyjavier", href: "https://www.threads.net/@unfiltrbyjavier" },
  { key: "bluesky", label: "Bluesky", handle: "@ihbnf.bsky.social", href: "https://bsky.app/profile/ihbnf.bsky.social" },
  { key: "pinterest", label: "Pinterest", handle: "ihbnfllc", href: "https://www.pinterest.com/ihbnfllc/" },
  // TODO: confirm the exact Facebook page URL.
  { key: "facebook", label: "Facebook", handle: "Unfiltr by Javier", href: "https://www.facebook.com/unfiltrbyjavier" },
];
